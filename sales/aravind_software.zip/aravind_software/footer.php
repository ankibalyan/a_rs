<div class="footer">
		<div class="header_top_one">
			<div class="row" style="margin:0px;">
			  <div class="col-md-4 col-md-offset-4">
			  	<p class="footer_p"> &copy Copyright 2015 Arvind Limited </p>
			  </div>
			</div>
			
		</div>
</div>
