<?php 
$hostname = "localhost";
$username = "root";
$password = "";
$database = "aravind";
$conn = mysql_connect($hostname, $username, $password, $database) or die('Error in connecting database');
mysql_select_db($database);
?>