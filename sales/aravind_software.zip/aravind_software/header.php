	<div class="header_top">
		<div class="header_top_one">
			<div class="row" style="margin:0px;">
			  <div class="col-md-3">
			  	<a href="index.php"> <img src="images/logo1.png" class="logo_style"> </a>
			  </div>
			  <div class="col-md-7 anchor">
					<div class="row"> 
						<div class="col-md-3 col-md-offset-1">	 
				<!--		 	<a href="#"><h4 class="logo_style_one"> Data Export </h4></a>  -->
						</div>
						<div class="col-md-3">	
				<!--			<a href="#"> <h4 class="logo_style_one"> User Manual </h4> </a>  <--></-->
						</div>
						
						<div class="col-md-5">		
							<script type="text/javascript">
								document.write (' <span id="date-time">', new Date().toLocaleString(), '<\/span>')
									if (document.getElementById) onload = function () {
										setInterval ("document.getElementById ('date-time').firstChild.data = new Date().toLocaleString()", 50)
									}
							</script>
						</div>
					</div>
			  </div>
			  <div class="col-md-2">
			  	<a href="login/logout.php"> <h4 class="logo_style"> <i class="fa fa-power-off"></i>  Logout </h4> </a>
			  </div>
			</div>
			
		</div>
	</div>